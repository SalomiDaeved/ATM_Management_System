﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management
{
    public partial class Withdraw : Form
    {
        public Withdraw()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Salomi\Documents\AT.mdf;Integrated Security=True;Connect Timeout=30");
        
        int bal;

        string Acc = Splash.AccNumber;
        private void getBalance()

        {
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select bal from AccTbl where AccNum='" + Acc + "'", Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            balancelbl.Text = " Balance Rs" + dt.Rows[0][0].ToString();
            bal = Convert.ToInt32(dt.Rows[0][0].ToString());
            Con.Close();

        }

        private void addtransaction()
        {


            string TrType = "Withdraw";

            try
            {
                Con.Open();
                string query = "Insert into TransTbl values('" + Acc + "','" + TrType + "','" + wdamtTb.Text + "', '" + DateTime.Today.Date.ToString() + "')";

                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                // MessageBox.Show("Account Created Successfully");



            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }























        private void Withdraw_Load(object sender, EventArgs e)
        {
            getBalance();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {

        }

        private void BunifuThinB_Click(object sender, EventArgs e)
        {


            int newbalance;
            if (wdamtTb.Text == "")
            {
                MessageBox.Show("Missing Information");

            }

            else if (Convert.ToInt32(wdamtTb.Text) <= 0)
            {
                MessageBox.Show("Ender a Valid Amount");

            }


            else if (Convert.ToInt32(wdamtTb.Text) > bal)
            {
                MessageBox.Show("Balance can not be negative");
            }


            else
            {

                newbalance = bal - Convert.ToInt32(wdamtTb.Text);
                try
                {
                    Con.Open();

                    string query = "update AccTbl set bal=" + newbalance + " where AccNum='" + Acc + "'";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Successfully Withdraw");



                    Con.Close();
                    addtransaction();




                    Home home = new Home();
                    home.Show();
                    this.Hide();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }



        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();









        }
    }
    }
    



       
        



       
        
  



