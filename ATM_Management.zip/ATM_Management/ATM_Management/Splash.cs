﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management
{
    public partial class Myprogrees : Form
    {
        public Myprogrees()
        {
            InitializeComponent();
        }
        int starting = 0;

        public static int Value { get; private set; }

        private void timer1_Tick(object sender, EventArgs e)
        {
            starting += 1;
            Myprogrees.Value=starting;
            Percentage.Text = "" + starting;
            if(Myprogrees.Value==100)
            {
                Myprogrees.Value = 0;
                timer1.Stop();
                Splash login = new Splash();
                this.Hide();
                login.Show();
            }
        }

        private void Myprogrees_Load(object sender, EventArgs e)
        {timer1.Start();

        }
    }
}
