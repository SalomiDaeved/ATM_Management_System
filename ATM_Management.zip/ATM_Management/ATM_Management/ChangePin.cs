﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ATM_Management
{
    public partial class ChangePin : Form
    {
        public ChangePin()
        {
            InitializeComponent();
        }

        private void Pin2Tb_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
       
        
      SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Salomi\Documents\AT.mdf;Integrated Security=True;Connect Timeout=30");
        string Acc = Splash.AccNumber;
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (Pin1Tb.Text == "" || Pin2.Text == "") {
                MessageBox.Show("Ender Conform the new pin");
            }

            else if(Pin2.Text!=Pin1Tb.Text)
            {
                MessageBox.Show("Pin1 and Pin2  are differend");
            }

            else
            {
                string Acc = Splash.AccNumber;
                //newbalance = oldbalance + Convert.ToInt32(DepoAmtTb.Text);
                try
                {
                    Con.Open();

                    string query = "update AccTbl set Pin=" + Pin1Tb.Text + " where AccNum='" + Acc + "'";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Pin successfully updated");


                    Con.Close();
                    Splash login = new Splash();
                    login.Show();
                    this.Hide();
                }

                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }


        }













    }
    }

