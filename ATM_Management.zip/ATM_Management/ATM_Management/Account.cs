﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ATM_Management
{
    public partial class Account : Form
    {
        public Account()
        {
            InitializeComponent();
        }

       
        SqlConnection Con=new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Salomi\Documents\AT.mdf;Integrated Security=True;Connect Timeout=30");


        private void Account_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label12_Click(object sender, EventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void label15_Click(object sender, EventArgs e)
        {

        }
        private void label5_Click(object sender, EventArgs e)
        {

        }
        private void label10_Click(object sender, EventArgs e)
        {

        }
        private void label11_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {


            int bal = 0;
            if (AccNameTb.Text == "" || AccNumTb.Text == "" || FnameTb.Text == "" || PhoneTb.Text == "" || PinTb.Text == "" || OccupationTb.Text == "" || AddressTb.Text == "")
            {
                MessageBox.Show("Missing Information");
            }

            else
            {
                try
                {
                    Con.Open();
                    string query = "Insert into AccTbl values('" + AccNumTb.Text + "','" + AccNameTb.Text + "','" + FnameTb.Text + "', '" + DateTb.Value.Date + "', '" + PhoneTb.Text + "','" + AddressTb.Text + "', '" + EducationTb.SelectedItem.ToString() + "','" + OccupationTb.Text + "', '"+PinTb.Text+"',"+bal+")";
                      
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Account Created Successfully");
                    Con.Close();

                   
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }



            }




            }

        private void AccNumTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {
            Splash login = new Splash();
            login.Show();
            this.Hide();
        }
    }

}