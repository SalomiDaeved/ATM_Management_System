﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Management
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Splash  login = new Splash(); 
            login.Show();
            this.Hide();
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            Balance bal=new Balance();
            this.Hide();
            bal.Show();
        }

        public static string AccNumber;


        private void Home_Load (object sender, EventArgs e)
        {
            AccNumlbl.Text = "Account Number:" + Splash.AccNumber;
            AccNumber= Splash.AccNumber;
        }

        private void bunifuThinButton26_Click_1(object sender, EventArgs e)
        {
            Balance bal = new Balance();
            bal.Show();
            this.Hide();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Deposit depo = new Deposit();
            depo.Show();
            this.Hide();
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            ChangePin changepin = new ChangePin();
            changepin.Show();
            this.Hide();

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            Withdraw wd=new Withdraw();
            wd.Show();
            this.Hide();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
          Fastcash  FC = new Fastcash();
            FC.Show();
            this.Hide();
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            Ministatement mini=new Ministatement();
            mini.Show();
            this.Hide();
        }
    }
    }

